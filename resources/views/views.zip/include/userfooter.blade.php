

                <div class="footer-wrapper">
            <div class="footer-section f-section-1">
                <p class="">Copyright © 2020 <a target="_blank" href="#">iTechQUeen Hub</a>, All rights reserved.</p>
            </div>
            <div class="footer-section f-section-2">
            </div>
        </div>
    </div>
    <!--  END CONTENT AREA  -->

    <script src="{{ asset('https://apps.elfsight.com/p/platform.js') }}" defer></script>

</div>
<!-- END MAIN CONTAINER -->

	<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
	<script src="{{ asset('assets/js/libs/jquery-3.1.1.min.js') }}"></script>
	<script src="{{ asset('bootstrap/js/popper.min.js') }}"></script>
	<script src="{{ asset('bootstrap/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
	<script src="{{ asset('assets/js/app.js') }}"></script>
	<script>
		$(document).ready(function() {
			App.init();
		});
	</script>
	<script src="{{ asset('assets/js/custom.js') }}"></script>
	<!-- END GLOBAL MANDATORY SCRIPTS -->