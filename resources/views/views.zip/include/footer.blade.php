<div class="footer">
		<p>&nbsp;</p>
		<p>&nbsp;</p>
    	<div class="container">
    		<div class="col-md-3 grid_4">
    		   <h3 style="color:yellow"><strong>Our Impact</strong></h3>	
    		   <p>"We are a delightful school with the child as the central focus of our educational programs which aim to be child friendly and fully accessible to all young learners."</p>
    		      
    		</div>
    		<div class="col-md-3 grid_4">
    		   <h3><strong>Contact Us</strong></h3>
    			<address>                  
                    <abbr><strong>Telephone :</strong><br> </abbr>
					+2349050717032 , +2348145272887
   			   </address>
    			<address>     
                    <abbr><strong>Email :</strong></abbr>
					<br>
					info@goldbridgeinterntionalschool.com
    			</address>
    			
    		</div>
    		<div class="col-md-3 grid_4">
    		   <h3 style="color:yellow"><strong>Contact Address</strong></h3>
    			<address>
                    <strong>Road 13 First Avenue New Road, off Ada George </strong>    
                    <span> Port Harcourt. Rivers State.</span>
					<ul class="social-nav icons_2 clearfix">
                    <li><a href="http://twitter.com/GBIS247" target="_blank"  class="twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.facebook.com/GBIS247/" target="_blank"  class="facebook"> <i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://www.google.com.ng/?gfe_rd=cr&ei=DXRvWO-uGMLCXrzMnPAF&gws_rd=ssl#q=gold+bridge+international+school" target="_blank" class="google-plus"><i class="fa fa-google-plus"></i></a></li>
                 </ul>
   			   </address>
    		</div>
    		<div class="col-md-3 grid_4">
    		   <h3><strong>Working Hours</strong></h3>
    			 <table class="table_working_hours">
		        	<tbody>
		        		<tr class="opened_1">
							<td class="day_label">monday - Thursday</td>
							<td class="day_value">7:00 am - 4.00 pm</td>
						</tr>
					    <tr class="opened">
							<td class="day_label">friday</td>
							<td class="day_value">7:00 am - 3.00 pm</td>
						</tr>
					    
				    </tbody>
				</table>
          </div>
			
    	  <div class="clearfix"> </div>
    		<div class="copy">
		       <br><p>Copyright © 2019 Gold Bridge Intl Sch . All Rights Reserved  | Design by <a href="https://itechqueen.com/" target="_blank">iTechQueen</a> </p>
	        </div>
    	</div>
    </div>
<script src="js/jquery.countdown.js"></script>
<script src="js/script.js"></script>
</body>
</html>